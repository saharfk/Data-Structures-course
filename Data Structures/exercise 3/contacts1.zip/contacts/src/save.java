import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class save {
	public static String cont1[];

	public static void read() {

		File f = new File("E:record.txt");
		if (f.exists() == true) {
			// do something
			BufferedReader br = null;
			FileReader fr = null;

			try {
				fr = new FileReader(RECORD);
				br = new BufferedReader(fr);

				String sCurrentLine;
				if ((sCurrentLine = br.readLine()) != null) {
					String[] contct = sCurrentLine.split("#");
					cont1 = contct;
				}

			} catch (IOException e1) {
				e1.printStackTrace();

			} finally {
				try {
					if (br != null)
						br.close();

					if (fr != null)
						fr.close();

				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
			for (int i = 0; i < cont1.length ; i++) {
				String[] key = cont1[i].split("!");
				main.contact[i].setName(key[0]);
				main.contact[i].setNumber(key[1]);
				if (key[2].equals("null") == false)
					main.contact[i].setAdress(key[2]);
				if (key[3].equals("null") == false)
					main.contact[i].setPosteCode(key[3]);
				if (key[4].equals("null") == false)
					main.contact[i].setEmail(key[4]);

				Trie.insert(key[0]);
				AdddContact.ininsert++;
				Trie.insert(key[1]);
				AdddContact.ininsert++;
			}
		}

	}

	private static final String RECORD = "E:record.txt";

	public static void save() {
		File f = new File("E:record.txt");
		if (f.exists() == true) {
			BufferedWriter bw = null;
			FileWriter fw = null;

			try {
				String content = "";// TODO
				for (int i = 0; i < searchDeleteContact.length(main.contact); i++) {
					

					try {
						if (main.contact[i].getName().equals("") == false) {
							content += main.contact[i].getName() + "!"
									+ main.contact[i].getNumber() + "!";
							try {
								content += main.contact[i].getAdress() + "!";
							} catch (NullPointerException e) {
								content += "!";
							}
							try {
								content += main.contact[i].getPosteCode() + "!";
							} catch (NullPointerException e) {
								content += "!";
							}
							try {
								content += main.contact[i].getEmail() + "#";
							} catch (NullPointerException e) {
								content += "#";
							}
						}
						fw = new FileWriter(RECORD, false);
						bw = new BufferedWriter(fw);
						bw.write(content);

					} catch (IOException e1) {
						e1.printStackTrace();

					} finally {
						try {
							if (bw != null)
								bw.close();

							if (fw != null)
								fw.close();

						} catch (IOException ex) {
							ex.printStackTrace();
						}
					}


						}
					} catch (NullPointerException e) {

					}

				
					
						} else {
			BufferedWriter bw = null;
			FileWriter fw = null;

			try {
				String content = "";// TODO
				for (int i = 0; i < searchDeleteContact.length(main.contact); i++) {
					

					try {
						if (main.contact[i].getName().equals("") == false) {
							content += main.contact[i].getName() + "!"
									+ main.contact[i].getNumber() + "!";
							try {
								content += main.contact[i].getAdress() + "!";
							} catch (NullPointerException e) {
								content += "!";
							}
							try {
								content += main.contact[i].getPosteCode() + "!";
							} catch (NullPointerException e) {
								content += "!";
							}
							try {
								content += main.contact[i].getEmail() + "#";
							} catch (NullPointerException e) {
								content += "#";
							}
						}
						fw = new FileWriter(RECORD, false);
						bw = new BufferedWriter(fw);
						bw.write(content);

					} catch (IOException e1) {
						e1.printStackTrace();

					} finally {
						try {
							if (bw != null)
								bw.close();

							if (fw != null)
								fw.close();

						} catch (IOException ex) {
							ex.printStackTrace();
						}
					}


						}
				fw = new FileWriter(RECORD);
				bw = new BufferedWriter(fw);
				bw.write(content);

			} catch (IOException e1) {
				e1.printStackTrace();

			} finally {
				try {
					if (bw != null)
						bw.close();

					if (fw != null)
						fw.close();

				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}

		}
		JOptionPane.showMessageDialog(new JFrame(),
				"saved!", "done",
				JOptionPane.ERROR_MESSAGE);
	
	}

}
