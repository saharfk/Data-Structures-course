import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.GroupLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

public class searchDeleteContact extends JFrame implements KeyListener {

	private JPanel contentPane;

	private JTextField txtName;
	private JTextField name;
	private JTextField txtNumber;
	private JTextField number;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					searchDeleteContact frame = new searchDeleteContact();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public searchDeleteContact() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel contentPane1 = new JPanel();
		contentPane1.setBackground(Color.BLACK);
		contentPane1.setForeground(Color.WHITE);

		txtName = new JTextField();
		txtName.setEditable(false);
		txtName.setText("name :");
		txtName.setBackground(Color.BLACK);
		txtName.setForeground(Color.WHITE);
		txtName.setBorder(null);
		txtName.setColumns(10);

		name = new JTextField();
		name.setBackground(Color.GRAY);
		name.setBorder(null);
		name.addKeyListener(this);
		name.setColumns(10);

		txtNumber = new JTextField();
		txtNumber.setEditable(false);
		txtNumber.setText("number :");
		txtNumber.setBackground(Color.BLACK);
		txtNumber.setForeground(Color.WHITE);
		txtNumber.setBorder(null);
		txtNumber.setColumns(10);

		number = new JTextField();
		number.setBackground(Color.GRAY);
		number.setBorder(null);
		number.setColumns(10);

		JButton btnNewButton = new JButton("search");
		btnNewButton.setBorder(null);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.DARK_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (name.getText().equals("") == false
						&& number.getText().equals("") == true) {
					boolean a = Trie.search(name.getText());
					if (a) {
						profile.name1 = main.contact[Trie.mem].getName();
						profile.number1 = main.contact[Trie.mem].getNumber();
						try {
							profile.email1 = main.contact[Trie.mem].getEmail();
						} catch (NullPointerException e) {
							profile.email1 = "unknown";
						}
						try {
							profile.postcode1 = main.contact[Trie.mem]
									.getPosteCode();
						} catch (NullPointerException e) {
							profile.postcode1 = "unknown";
						}
						try {
							profile.adress1 = main.contact[Trie.mem]
									.getAdress();
						} catch (NullPointerException e) {
							profile.adress1 = "unknown";
						}

						new profile().setVisible(true);
						dispose();
					} else {
						JOptionPane.showMessageDialog(new JFrame(),
								"contact doesn't exist", "ERROR!!",
								JOptionPane.ERROR_MESSAGE);
					}
				} else if (name.getText().equals("") == true
						&& number.getText().equals("") == false) {

					boolean a = Trie.search(number.getText());
					if (a) {
						profile.name1 = main.contact[Trie.mem].getName();
						profile.number1 = main.contact[Trie.mem].getNumber();
						try {
							profile.email1 = main.contact[Trie.mem].getEmail();
						} catch (NullPointerException e) {
							profile.email1 = "unknown";
						}
						try {
							profile.postcode1 = main.contact[Trie.mem]
									.getPosteCode();
						} catch (NullPointerException e) {
							profile.postcode1 = "unknown";
						}
						try {
							profile.adress1 = main.contact[Trie.mem]
									.getAdress();
						} catch (NullPointerException e) {
							profile.adress1 = "unknown";
						}

						new profile().setVisible(true);
						dispose();
					} else {
						JOptionPane.showMessageDialog(new JFrame(),
								"contact doesn't exist", "ERROR!!",
								JOptionPane.ERROR_MESSAGE);
					}

				} else {
					JOptionPane.showMessageDialog(new JFrame(),
							"fill one of the boxes", "ERROR!!",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnNewButton_1 = new JButton("delete");
		btnNewButton_1.setBorder(null);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (name.getText().equals("") == false
						&& number.getText().equals("") == true) {
					boolean a = Trie.search(name.getText());
					if (a) {
						Trie.delete(name.getText());
						editeContact.y++;
						Trie.delete(main.contact[Trie.mem].getNumber());
						editeContact.y++;
						JOptionPane.showMessageDialog(new JFrame(),
								"contact deleted!!", "DONE!!",
								JOptionPane.ERROR_MESSAGE);
						new welcome().setVisible(true);
						dispose();
					} else {
						JOptionPane.showMessageDialog(new JFrame(),
								"contact doesn't exist", "ERROR!!",
								JOptionPane.ERROR_MESSAGE);
					}
				} else if (name.getText().equals("") == true
						&& number.getText().equals("") == false) {

					boolean a = Trie.search(number.getText());
					if (a) {
						Trie.delete(main.contact[Trie.mem].getName());
						editeContact.y++;
						Trie.delete(number.getText());
						editeContact.y++;
						JOptionPane.showMessageDialog(new JFrame(),
								"contact deleted!!", "DONE!!",
								JOptionPane.ERROR_MESSAGE);
						new welcome().setVisible(true);
						dispose();
					} else {
						JOptionPane.showMessageDialog(new JFrame(),
								"contact doesn't exist", "ERROR!!",
								JOptionPane.ERROR_MESSAGE);
					}

				} else {
					JOptionPane.showMessageDialog(new JFrame(),
							"fill one of the boxes", "ERROR!!",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.setForeground(Color.WHITE);

		btnNewButton_2 = new JButton("HOME");
		btnNewButton_2.setBorder(null);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new welcome().setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBackground(Color.DARK_GRAY);
		btnNewButton_2.setForeground(Color.WHITE);
		GroupLayout gl_contentPane1 = new GroupLayout(contentPane1);
		gl_contentPane1
				.setHorizontalGroup(gl_contentPane1
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane1
										.createSequentialGroup()
										.addGap(33)
										.addGroup(
												gl_contentPane1
														.createParallelGroup(
																Alignment.TRAILING,
																false)
														.addComponent(txtNumber)
														.addComponent(txtName)
														.addGroup(
																Alignment.LEADING,
																gl_contentPane1
																		.createSequentialGroup()
																		.addComponent(
																				btnNewButton_2,
																				GroupLayout.PREFERRED_SIZE,
																				71,
																				GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				ComponentPlacement.RELATED)))
										.addGroup(
												gl_contentPane1
														.createParallelGroup(
																Alignment.TRAILING)
														.addGroup(
																gl_contentPane1
																		.createSequentialGroup()
																		.addGap(65)
																		.addGroup(
																				gl_contentPane1
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(
																								number,
																								GroupLayout.DEFAULT_SIZE,
																								194,
																								Short.MAX_VALUE)
																						.addComponent(
																								name,
																								GroupLayout.DEFAULT_SIZE,
																								194,
																								Short.MAX_VALUE)))
														.addGroup(
																gl_contentPane1
																		.createSequentialGroup()
																		.addGap(35)
																		.addComponent(
																				btnNewButton_1,
																				GroupLayout.PREFERRED_SIZE,
																				89,
																				GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				ComponentPlacement.RELATED,
																				46,
																				Short.MAX_VALUE)
																		.addComponent(
																				btnNewButton,
																				GroupLayout.PREFERRED_SIZE,
																				89,
																				GroupLayout.PREFERRED_SIZE)))
										.addGap(52)));
		gl_contentPane1
				.setVerticalGroup(gl_contentPane1
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane1
										.createSequentialGroup()
										.addGap(38)
										.addGroup(
												gl_contentPane1
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																name,
																GroupLayout.PREFERRED_SIZE,
																24,
																GroupLayout.PREFERRED_SIZE))
										.addGap(36)
										.addGroup(
												gl_contentPane1
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtNumber,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																number,
																GroupLayout.PREFERRED_SIZE,
																25,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.RELATED, 55,
												Short.MAX_VALUE)
										.addGroup(
												gl_contentPane1
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																btnNewButton,
																GroupLayout.PREFERRED_SIZE,
																37,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																btnNewButton_2,
																GroupLayout.PREFERRED_SIZE,
																30,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																btnNewButton_1,
																GroupLayout.PREFERRED_SIZE,
																34,
																GroupLayout.PREFERRED_SIZE))
										.addGap(36)));
		contentPane1.setLayout(gl_contentPane1);
		contentPane.add(contentPane1, BorderLayout.CENTER);
		// ******************************************************
	}

	public static int length(contact[] arr) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].getName() == null && arr[i + 1].getName() == null
					&& arr[i + 2].getName() == null) {
				return i;
			}
		}
		return 200;
	}

	public void keyPressed(KeyEvent txt) {
		String[] a = Trie.secSearch(name.getText() + txt.getKeyChar());
		JPanel contentPane2 = new JPanel();
		contentPane2.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane2.setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane = new JScrollPane();
		contentPane2.add(scrollPane, BorderLayout.CENTER);

		JScrollBar scrollBar = new JScrollBar();
		scrollPane.setRowHeaderView(scrollBar);
		int p = 1;
		JPanel vasat = new JPanel();
		vasat = new JPanel();
		vasat.setLayout(new GridLayout(6, 7, 0, 0));
		final JButton[] jb = new JButton[a.length + 1];
		for (int i = 0; i < a.length + 1; i++) {
			final JButton jb1 = new JButton();
			if (p % 2 == 0) {
				jb1.setBackground(Color.gray);
			} else
				jb1.setBackground(Color.LIGHT_GRAY);
			p++;
			if (i == a.length) {
				jb1.setText("home");
			} else
				jb1.setText(a[i]);
			jb[i] = jb1;
			jb1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String a = jb1.getText();
					if (a == "home") {
						new welcome().setVisible(true);
						dispose();
					} else {
						Trie.search(a);
						profile.name1 = main.contact[Trie.mem].getName();
						profile.number1 = main.contact[Trie.mem].getNumber();
						try {
							profile.adress1 = main.contact[Trie.mem]
									.getAdress();
						} catch (NullPointerException e2) {
							profile.adress1 = "unknown";
						}
						try {
							profile.email1 = main.contact[Trie.mem].getEmail();
						} catch (NullPointerException e2) {
							profile.email1 = "unknown";
						}
						try {
							profile.postcode1 = main.contact[Trie.mem]
									.getPosteCode();
						} catch (NullPointerException e2) {
							profile.email1 = "unknown";
						}

						new profile().setVisible(true);
						dispose();
					}
				}
			});
			vasat.add(jb[i]);
		}
		scrollPane.setViewportView(vasat);

		contentPane.add(contentPane2, BorderLayout.EAST);
	}

	public void keyReleased(KeyEvent txt) {
		// TODO Auto-generated method stub

	}

	public void keyTyped(KeyEvent txt) {
		// TODO Auto-generated method stub

	}

}
