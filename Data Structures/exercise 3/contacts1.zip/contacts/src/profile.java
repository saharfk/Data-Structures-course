import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;

public class profile extends JFrame {

	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtNumber;
	private JTextField txtEmail;
	private JTextField txtAdress;
	private JTextField txtPostCode;
	private JTextField name;
	private JTextField number;
	private JTextField email;
	private JTextField adress;
	private JTextField postcode;
	public static String name1, number1, email1, postcode1, adress1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					profile frame = new profile();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public profile() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JButton btnHome = new JButton("home");
		btnHome.setBorder(null);
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new welcome().setVisible(true);
				dispose();
			}
		});
		btnHome.setBackground(Color.DARK_GRAY);
		btnHome.setForeground(Color.WHITE);

		txtName = new JTextField();
		txtName.setEditable(false);
		txtName.setForeground(Color.WHITE);
		txtName.setBackground(Color.BLACK);
		txtName.setText("name :");
		txtName.setColumns(10);
		txtName.setBorder(null);

		txtNumber = new JTextField();
		txtNumber.setEditable(false);
		txtNumber.setForeground(Color.WHITE);
		txtNumber.setBackground(Color.BLACK);
		txtNumber.setText("number :");
		txtNumber.setColumns(10);
		txtNumber.setBorder(null);

		txtEmail = new JTextField();
		txtEmail.setForeground(Color.WHITE);
		txtEmail.setBackground(Color.BLACK);
		txtEmail.setEditable(false);
		txtEmail.setText("email :");
		txtEmail.setColumns(10);
		txtEmail.setBorder(null);

		txtAdress = new JTextField();
		txtAdress.setForeground(Color.WHITE);
		txtAdress.setBackground(Color.BLACK);
		txtAdress.setEditable(false);
		txtAdress.setText("adress :");
		txtAdress.setColumns(10);
		txtAdress.setBorder(null);

		txtPostCode = new JTextField();
		txtPostCode.setEditable(false);
		txtPostCode.setBackground(Color.BLACK);
		txtPostCode.setForeground(Color.WHITE);
		txtPostCode.setText("post code :");
		txtPostCode.setColumns(10);
		txtPostCode.setBorder(null);

		name = new JTextField();
		name.setEditable(false);
		name.setBackground(Color.GRAY);
		name.setColumns(10);
		name.setBorder(null);

		number = new JTextField();
		number.setEditable(false);
		number.setBackground(Color.GRAY);
		number.setColumns(10);
		number.setBorder(null);

		email = new JTextField();
		email.setEditable(false);
		email.setBackground(Color.GRAY);
		email.setColumns(10);
		email.setBorder(null);

		adress = new JTextField();
		adress.setEditable(false);
		adress.setBackground(Color.GRAY);
		adress.setColumns(10);
		adress.setBorder(null);

		postcode = new JTextField();
		postcode.setEditable(false);
		postcode.setBackground(Color.GRAY);
		postcode.setColumns(10);
		postcode.setBorder(null);
		
		name.setText(name1);
		number.setText(number1);
		adress.setText(adress1);
		postcode.setText(postcode1);
		email.setText(email1);
		
		
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane
						.createParallelGroup(Alignment.TRAILING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addComponent(
																txtName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtNumber,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtEmail,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtAdress,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtPostCode,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGap(41)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addComponent(
																postcode,
																GroupLayout.DEFAULT_SIZE,
																233,
																Short.MAX_VALUE)
														.addComponent(adress,
																233, 233, 233)
														.addGroup(
																gl_contentPane
																		.createParallelGroup(
																				Alignment.LEADING,
																				false)
																		.addComponent(
																				email)
																		.addComponent(
																				number)
																		.addComponent(
																				name,
																				GroupLayout.DEFAULT_SIZE,
																				233,
																				Short.MAX_VALUE)))
										.addGap(54))
						.addGroup(
								Alignment.LEADING,
								gl_contentPane
										.createSequentialGroup()
										.addGap(162)
										.addComponent(btnHome,
												GroupLayout.PREFERRED_SIZE, 82,
												GroupLayout.PREFERRED_SIZE)
										.addContainerGap(180, Short.MAX_VALUE)));
		gl_contentPane
				.setVerticalGroup(gl_contentPane
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																name,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtNumber,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																number,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtEmail,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																email,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtAdress,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																adress,
																GroupLayout.PREFERRED_SIZE,
																38,
																GroupLayout.PREFERRED_SIZE))
										.addGap(18)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addComponent(
																postcode,
																GroupLayout.PREFERRED_SIZE,
																36,
																GroupLayout.PREFERRED_SIZE)
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addComponent(
																				txtPostCode,
																				GroupLayout.PREFERRED_SIZE,
																				GroupLayout.DEFAULT_SIZE,
																				GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				ComponentPlacement.RELATED)))
										.addPreferredGap(
												ComponentPlacement.RELATED, 22,
												Short.MAX_VALUE)
										.addComponent(btnHome,
												GroupLayout.PREFERRED_SIZE, 37,
												GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));
		contentPane.setLayout(gl_contentPane);
	}
}
