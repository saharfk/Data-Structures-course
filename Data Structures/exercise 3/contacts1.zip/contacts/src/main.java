public class main {
	public static int[] stack=new int[200];
	public static int tahestack=stack.length-1;
	public static contact contact[]=new contact[200];
	public static void push(int item){
		stack[tahestack]=item;
		tahestack++;
	}
	public static int pop(){
		tahestack--;
		return stack[tahestack+1];
	}
//	public static void main(String[] args) {
//		 contact contact[]=new contact[3];
//		 for(int i=0;i<3;i++){
//			 contact[0]=new contact();
//		 }
//		contact[0].setName("fujf");
//	System.out.println(contact[0].getName());
//	}
}
