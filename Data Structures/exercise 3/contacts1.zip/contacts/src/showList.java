import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.JButton;
import javax.swing.JTextArea;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class showList extends JFrame {

	private JPanel contentPane2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					showList frame = new showList();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public showList() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane2 = new JPanel();
		contentPane2.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane2.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane2);

		JScrollPane scrollPane = new JScrollPane();
		contentPane2.add(scrollPane, BorderLayout.CENTER);

		JScrollBar scrollBar = new JScrollBar();
		scrollPane.setRowHeaderView(scrollBar);
		int p = 1;
		JPanel vasat = new JPanel();
		vasat = new JPanel();
		vasat.setLayout(new GridLayout(6, 7, 0, 0));
		final JButton[] jb = new JButton[searchDeleteContact.length(main.contact)+2];
		for (int i = 0; i < searchDeleteContact.length(main.contact)+2; i++) {
			final JButton jb1 = new JButton();
			if (p % 2 == 0) {
				jb1.setBackground(Color.gray);
				jb1.setForeground(Color.white);
			} else
				jb1.setBackground(Color.LIGHT_GRAY);
			p++;
			if (i == searchDeleteContact.length(main.contact)) {
				jb1.setText("home");
				jb[i] = jb1;
			} else if (i == searchDeleteContact.length(main.contact)+1) {
				jb1.setText("save");
				jb[i] = jb1;
			} else {
				try {
					if (main.contact[i].getName().equals("") == false) {
						jb1.setText(main.contact[i].getName());
						jb[i] = jb1;
					}
				} catch (NullPointerException e) {

				}

			}

			jb1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String a = jb1.getText();
					if (a == "home") {
						new welcome().setVisible(true);
						dispose();
					} else if (a == "save") {
						save.save();
					} else {
						Trie.search(a);
						profile.name1 = main.contact[Trie.mem].getName();
						profile.number1 = main.contact[Trie.mem].getNumber();
						try {
							profile.adress1 = main.contact[Trie.mem]
									.getAdress();
						} catch (NullPointerException e2) {
							profile.adress1 = "unknown";
						}
						try {
							profile.email1 = main.contact[Trie.mem].getEmail();
						} catch (NullPointerException e2) {
							profile.email1 = "unknown";
						}
						try {
							profile.postcode1 = main.contact[Trie.mem]
									.getPosteCode();
						} catch (NullPointerException e2) {
							profile.email1 = "unknown";
						}

						new profile().setVisible(true);
						dispose();
					}
				}
			});
			try {
				vasat.add(jb[i]);
			} catch (NullPointerException e) {

			}
		}

		scrollPane.setViewportView(vasat);
	}

}
