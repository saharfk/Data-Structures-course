import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class welcome extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		for(int i=0;i<main.contact.length;i++){
			main.contact[i]=new contact();
		}
		for (int i = 0; i < main.stack.length; i++) {
			main.stack[i] = main.stack.length - i - 1;
		}
		Trie.root = new Trie.TrieNode();
		save.read();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					welcome frame = new welcome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public welcome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setResizable(false);
		JButton btnSearch = new JButton("search/delete contact");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new searchDeleteContact().setVisible(true);
				dispose();
			}
		});
		btnSearch.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		btnSearch.setBackground(Color.DARK_GRAY);
		btnSearch.setForeground(Color.WHITE);
		btnSearch.setBorder(null);
		contentPane.add(btnSearch, BorderLayout.NORTH);
		
		JButton addContact = new JButton(" add \rcontact");
		addContact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new AdddContact().setVisible(true);
				dispose();
			}
		});
		addContact.setFont(new Font("Tempus Sans ITC", Font.BOLD, 12));
		addContact.setBackground(Color.GRAY);
		addContact.setForeground(Color.WHITE);
		addContact.setBorder(null);
		contentPane.add(addContact, BorderLayout.WEST);
		
		JButton editeContact = new JButton(" edite \rcontact");
		editeContact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new editeContact().setVisible(true);
				dispose();
			}
		});
		editeContact.setFont(new Font("Tempus Sans ITC", Font.BOLD, 12));
		editeContact.setBackground(Color.GRAY);
		editeContact.setForeground(Color.WHITE);
		editeContact.setBorder(null);
		contentPane.add(editeContact, BorderLayout.EAST);
		
		JButton btnWelcome = new JButton("WELCOME");
		btnWelcome.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		btnWelcome.setBackground(Color.BLACK);
		btnWelcome.setForeground(Color.WHITE);
		btnWelcome.setBorder(null);
		btnWelcome.setEnabled(false);
		contentPane.add(btnWelcome, BorderLayout.CENTER);
		
		JButton btnShowContacts = new JButton("show contacts");
		btnShowContacts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new showList().setVisible(true);
				dispose();
			}
		});
		btnShowContacts.setBackground(Color.DARK_GRAY);
		btnShowContacts.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		btnShowContacts.setForeground(Color.WHITE);
		btnShowContacts.setBorder(null);
		contentPane.add(btnShowContacts, BorderLayout.SOUTH);
	}

}
