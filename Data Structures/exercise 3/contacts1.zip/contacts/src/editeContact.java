import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import java.awt.Font;

public class editeContact extends JFrame {
	public static int y = 1;
	private JPanel contentPane4;
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtNumber;
	private JTextField name;
	private JTextField number;
	private JButton btnNewButton_1;
	private JTextField txtPleaseJustFill;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					editeContact frame = new editeContact();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public editeContact() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane4 = new JPanel();
		contentPane4.setBackground(Color.BLACK);
		contentPane4.setForeground(Color.WHITE);

		txtName = new JTextField();
		txtName.setText("name :");
		txtName.setForeground(Color.WHITE);
		txtName.setEditable(false);
		txtName.setBorder(null);
		txtName.setBackground(Color.BLACK);
		txtName.setColumns(10);

		txtNumber = new JTextField();
		txtNumber.setText("number :");
		txtNumber.setEditable(false);
		txtNumber.setBorder(null);
		txtNumber.setForeground(Color.WHITE);
		txtNumber.setBackground(Color.BLACK);
		txtNumber.setColumns(10);

		name = new JTextField();
		name.setBackground(Color.GRAY);
		name.setColumns(10);
		name.setBorder(null);

		number = new JTextField();
		number.setBackground(Color.GRAY);
		number.setColumns(10);
		number.setBorder(null);

		JButton btnNewButton = new JButton("edite");
		btnNewButton.setBorder(null);
		btnNewButton.setBackground(Color.DARK_GRAY);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (name.getText().equals("") == false
						&& number.getText().equals("") == true) {
					boolean a = Trie.search(name.getText());
					if (a) {
						AdddContact.flg++;
						AdddContact.Ename = main.contact[Trie.mem].getName();
						AdddContact.Enumber = main.contact[Trie.mem]
								.getNumber();
						try {
							AdddContact.Eemail = main.contact[Trie.mem]
									.getEmail();
						} catch (NullPointerException e) {
							AdddContact.Eemail = "";
						}
						try {
							AdddContact.Epostecode = main.contact[Trie.mem]
									.getPosteCode();
						} catch (NullPointerException e) {
							AdddContact.Epostecode = "";
						}
						try {
							AdddContact.Eadress = main.contact[Trie.mem]
									.getAdress();
						} catch (NullPointerException e) {
							AdddContact.Eadress = "";
						}
						Trie.delete(name.getText());
						y++;
						Trie.delete(main.contact[Trie.mem].getNumber());
						y++;
						new AdddContact().setVisible(true);
						dispose();

					} else {
						JOptionPane.showMessageDialog(new JFrame(),
								"contact doesn't exist", "ERROR!!",
								JOptionPane.ERROR_MESSAGE);
					}
					// *********************************************
				} else if (name.getText().equals("") == true
						&& number.getText().equals("") == false) {

					boolean a = Trie.search(number.getText());
					if (a) {
						AdddContact.flg++;
						AdddContact.Ename = main.contact[Trie.mem].getName();
						AdddContact.Enumber = main.contact[Trie.mem]
								.getNumber();
						try {
							AdddContact.Eemail = main.contact[Trie.mem]
									.getEmail();
						} catch (NullPointerException e) {
							AdddContact.Eemail = "";
						}
						try {
							AdddContact.Epostecode = main.contact[Trie.mem]
									.getPosteCode();
						} catch (NullPointerException e) {
							AdddContact.Epostecode = "";
						}
						try {
							AdddContact.Eadress = main.contact[Trie.mem]
									.getAdress();
						} catch (NullPointerException e) {
							AdddContact.Eadress = "";
						}
						Trie.delete(number.getText());
						y++;
						System.out.println(main.contact[Trie.mem].getName());
						Trie.delete(main.contact[Trie.mem].getName());
						y++;
						new AdddContact().setVisible(true);
						dispose();

					} else {
						JOptionPane.showMessageDialog(new JFrame(),
								"contact doesn't exist", "ERROR!!",
								JOptionPane.ERROR_MESSAGE);
					}

				} else {
					JOptionPane.showMessageDialog(new JFrame(),
							"fill one of the boxes", "ERROR!!",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnNewButton_1 = new JButton("HOME");
		btnNewButton_1.setBorder(null);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new welcome().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.setForeground(Color.WHITE);

		txtPleaseJustFill = new JTextField();
		txtPleaseJustFill.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtPleaseJustFill.setHorizontalAlignment(SwingConstants.CENTER);
		txtPleaseJustFill.setBackground(Color.BLACK);
		txtPleaseJustFill.setEditable(false);
		txtPleaseJustFill.setForeground(Color.WHITE);
		txtPleaseJustFill.setBorder(null);
		txtPleaseJustFill.setText("please just fill one of the boxes :)");
		txtPleaseJustFill.setColumns(10);
		GroupLayout gl_contentPane4 = new GroupLayout(contentPane4);
		gl_contentPane4
				.setHorizontalGroup(gl_contentPane4
						.createParallelGroup(Alignment.TRAILING)
						.addGroup(
								Alignment.LEADING,
								gl_contentPane4
										.createSequentialGroup()
										.addGap(18)
										.addGroup(
												gl_contentPane4
														.createParallelGroup(
																Alignment.LEADING)
														.addComponent(
																txtName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtNumber,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGap(47)
										.addGroup(
												gl_contentPane4
														.createParallelGroup(
																Alignment.TRAILING,
																false)
														.addComponent(name)
														.addComponent(
																number,
																GroupLayout.DEFAULT_SIZE,
																230,
																Short.MAX_VALUE))
										.addContainerGap(49, Short.MAX_VALUE))
						.addGroup(
								gl_contentPane4
										.createSequentialGroup()
										.addContainerGap(81, Short.MAX_VALUE)
										.addGroup(
												gl_contentPane4
														.createParallelGroup(
																Alignment.LEADING,
																false)
														.addComponent(
																txtPleaseJustFill,
																Alignment.TRAILING)
														.addGroup(
																Alignment.TRAILING,
																gl_contentPane4
																		.createSequentialGroup()
																		.addComponent(
																				btnNewButton_1,
																				GroupLayout.PREFERRED_SIZE,
																				88,
																				GroupLayout.PREFERRED_SIZE)
																		.addGap(59)
																		.addComponent(
																				btnNewButton,
																				GroupLayout.PREFERRED_SIZE,
																				101,
																				GroupLayout.PREFERRED_SIZE)))
										.addGap(95)));
		gl_contentPane4
				.setVerticalGroup(gl_contentPane4
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane4
										.createSequentialGroup()
										.addGap(47)
										.addGroup(
												gl_contentPane4
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																name,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGap(18)
										.addGroup(
												gl_contentPane4
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtNumber,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																number,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGap(18)
										.addComponent(txtPleaseJustFill,
												GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												ComponentPlacement.RELATED, 32,
												Short.MAX_VALUE)
										.addGroup(
												gl_contentPane4
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																btnNewButton,
																GroupLayout.PREFERRED_SIZE,
																33,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																btnNewButton_1,
																GroupLayout.PREFERRED_SIZE,
																31,
																GroupLayout.PREFERRED_SIZE))
										.addGap(55)));
		contentPane4.setLayout(gl_contentPane4);
		contentPane.add(contentPane4, BorderLayout.CENTER);
		
		
		JPanel contentPane2 = new JPanel();
		contentPane2.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane2.setLayout(new BorderLayout(0, 0));
		

		JScrollPane scrollPane = new JScrollPane();
		contentPane2.add(scrollPane, BorderLayout.CENTER);

		JScrollBar scrollBar = new JScrollBar();
		scrollPane.setRowHeaderView(scrollBar);
		int p = 1;
		JPanel vasat = new JPanel();
		vasat = new JPanel();
		vasat.setLayout(new GridLayout(6, 7, 0, 0));
		final JButton[] jb = new JButton[searchDeleteContact.length(main.contact)];
		for (int i = 0; i < searchDeleteContact.length(main.contact); i++) {
			final JButton jb1 = new JButton();
			if (p % 2 == 0) {
				jb1.setBackground(Color.gray);
				jb1.setForeground(Color.white);
			} else
				jb1.setBackground(Color.LIGHT_GRAY);
			p++;
				jb1.setText(main.contact[i].getName());
			jb[i] = jb1;
			jb1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String a = jb1.getText();
						Trie.search(a);
						AdddContact.flg++;
						AdddContact.Ename = main.contact[Trie.mem].getName();
						AdddContact.Enumber = main.contact[Trie.mem].getNumber();
						try {
							AdddContact.Eadress = main.contact[Trie.mem]
									.getAdress();
						} catch (NullPointerException e2) {
							AdddContact.Eadress = "unknown";
						}
						try {
							AdddContact.Eemail = main.contact[Trie.mem].getEmail();
						} catch (NullPointerException e2) {
							AdddContact.Eemail = "unknown";
						}
						try {
							AdddContact.Epostecode = main.contact[Trie.mem]
									.getPosteCode();
						} catch (NullPointerException e2) {
							AdddContact.Epostecode = "unknown";
						}
						boolean aa = Trie.search(number.getText());
						Trie.delete(main.contact[Trie.mem].getName());
						y++;
						Trie.delete(main.contact[Trie.mem].getNumber());
						y++;
						new AdddContact().setVisible(true);
						dispose();
					
				}
			});
			vasat.add(jb[i]);
		}

		scrollPane.setViewportView(vasat);
		contentPane.add(contentPane2, BorderLayout.EAST);
	}
}
