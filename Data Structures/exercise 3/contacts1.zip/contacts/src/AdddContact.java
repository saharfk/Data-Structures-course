import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdddContact extends JFrame {
	public static int ininsert = 1;
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtNumber;
	private JTextField name;
	private JTextField number;
	private JTextField txtEmailoptional;
	private JTextField txtAdressoptional;
	private JTextField email;
	private JTextField adress;
	private JTextField txtPostcodeoptional;
	private JTextField postecode;
	public static String Ename, Enumber, Eemail, Eadress, Epostecode;
	public static int flg = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdddContact frame = new AdddContact();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdddContact() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setContentPane(contentPane);

		txtName = new JTextField();
		txtName.setEditable(false);
		txtName.setBorder(null);
		txtName.setText("nameFamlily :");
		txtName.setForeground(Color.WHITE);
		txtName.setBackground(Color.BLACK);
		txtName.setColumns(10);

		txtNumber = new JTextField();
		txtNumber.setEditable(false);
		txtNumber.setBorder(null);
		txtNumber.setText("number :");
		txtNumber.setBackground(Color.BLACK);
		txtNumber.setForeground(Color.WHITE);
		txtNumber.setColumns(10);

		name = new JTextField();
		name.setBackground(Color.GRAY);
		name.setBorder(null);
		name.setColumns(10);

		number = new JTextField();
		number.setBorder(null);
		number.setBackground(Color.GRAY);
		number.setColumns(10);
		if (flg == 1) {
			name.setText(Ename);
			number.setText(Enumber);
			try {
				adress.setText(Eadress);
			} catch (NullPointerException e) {

			}
			try {
				postecode.setText(Epostecode);
			} catch (NullPointerException e) {

			}
			try {
				email.setText(Eemail);
			} catch (NullPointerException e) {

			}
			flg = 0;
		}

		JButton btnNewButton = new JButton("submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (name.getText().equals("") || number.getText().equals("")) {
					JOptionPane.showMessageDialog(new JFrame(),
							"please fill the not optional fields",
							"be careful!!", JOptionPane.ERROR_MESSAGE);
				} else {
					main.contact[main.stack[main.tahestack]].setName(name
							.getText());
					main.contact[main.stack[main.tahestack]].setNumber(number
							.getText());
					if (email.getText().equals("") == false) {
						main.contact[main.stack[main.tahestack]].setEmail(email
								.getText());
					}
					if (adress.getText().equals("") == false) {
						main.contact[main.stack[main.tahestack]]
								.setAdress(adress.getText());
					}
					if (postecode.getText().equals("") == false) {
						main.contact[main.stack[main.tahestack]]
								.setPosteCode(postecode.getText());
					}
					if (Trie.search(name.getText())
							|| Trie.search(number.getText())) {
						JOptionPane.showMessageDialog(new JFrame(),
								"contact exists\n try some thing else",
								"ERROR!", JOptionPane.ERROR_MESSAGE);
					} else {
						Trie.insert(name.getText());
						ininsert++;
						Trie.insert(number.getText());
						ininsert++;
						JOptionPane.showMessageDialog(new JFrame(),
								"operation has been done correctly", "done!",
								JOptionPane.ERROR_MESSAGE);
						name.setText("");
						number.setText("");
						email.setText("");
						postecode.setText("");
						adress.setText("");

						new welcome().setVisible(true);
						dispose();
					}
				}
			}
		});
		btnNewButton.setBorder(null);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.DARK_GRAY);

		txtEmailoptional = new JTextField();
		txtEmailoptional.setEditable(false);
		txtEmailoptional.setBorder(null);
		txtEmailoptional.setText("email (optional) :");
		txtEmailoptional.setForeground(Color.WHITE);
		txtEmailoptional.setBackground(Color.BLACK);
		txtEmailoptional.setColumns(10);

		txtAdressoptional = new JTextField();
		txtAdressoptional.setBorder(null);
		txtAdressoptional.setEditable(false);
		txtAdressoptional.setText("adress (optional) :");
		txtAdressoptional.setBackground(Color.BLACK);
		txtAdressoptional.setForeground(Color.WHITE);
		txtAdressoptional.setColumns(10);

		email = new JTextField();
		email.setBorder(null);
		email.setBackground(Color.GRAY);
		email.setColumns(10);

		adress = new JTextField();
		adress.setBorder(null);
		adress.setBackground(Color.GRAY);
		adress.setColumns(10);

		txtPostcodeoptional = new JTextField();
		txtPostcodeoptional.setBorder(null);
		txtPostcodeoptional.setEditable(false);
		txtPostcodeoptional.setText("postcode (optional) :");
		txtPostcodeoptional.setForeground(Color.WHITE);
		txtPostcodeoptional.setBackground(Color.BLACK);
		txtPostcodeoptional.setColumns(10);

		postecode = new JTextField();
		postecode.setBorder(null);
		postecode.setBackground(Color.GRAY);
		postecode.setColumns(10);

		JButton btnNewButton_1 = new JButton("HOME");
		btnNewButton_1.setBorder(null);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new welcome().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.setForeground(Color.WHITE);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addContainerGap()
																		.addGroup(
																				gl_contentPane
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addGroup(
																								gl_contentPane
																										.createParallelGroup(
																												Alignment.LEADING,
																												false)
																										.addComponent(
																												txtPostcodeoptional)
																										.addComponent(
																												txtEmailoptional,
																												Alignment.TRAILING,
																												GroupLayout.DEFAULT_SIZE,
																												118,
																												Short.MAX_VALUE)
																										.addComponent(
																												txtNumber,
																												Alignment.TRAILING)
																										.addComponent(
																												txtName,
																												Alignment.TRAILING))
																						.addComponent(
																								txtAdressoptional,
																								139,
																								139,
																								139))
																		.addPreferredGap(
																				ComponentPlacement.RELATED)
																		.addGroup(
																				gl_contentPane
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(
																								number,
																								241,
																								241,
																								241)
																						.addComponent(
																								email,
																								241,
																								241,
																								241)
																						.addComponent(
																								adress,
																								241,
																								241,
																								241)
																						.addComponent(
																								name,
																								GroupLayout.PREFERRED_SIZE,
																								241,
																								GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								postecode,
																								241,
																								241,
																								241)))
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addGap(58)
																		.addComponent(
																				btnNewButton,
																				GroupLayout.PREFERRED_SIZE,
																				109,
																				GroupLayout.PREFERRED_SIZE)
																		.addGap(46)
																		.addComponent(
																				btnNewButton_1,
																				GroupLayout.PREFERRED_SIZE,
																				106,
																				GroupLayout.PREFERRED_SIZE)))
										.addContainerGap(38, Short.MAX_VALUE)));
		gl_contentPane
				.setVerticalGroup(gl_contentPane
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_contentPane
										.createSequentialGroup()
										.addGap(25)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																txtName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																name,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGap(18)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																number,
																GroupLayout.PREFERRED_SIZE,
																14,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtNumber,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addGap(16)
																		.addComponent(
																				txtEmailoptional,
																				GroupLayout.PREFERRED_SIZE,
																				GroupLayout.DEFAULT_SIZE,
																				GroupLayout.PREFERRED_SIZE))
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addGap(18)
																		.addComponent(
																				email,
																				GroupLayout.PREFERRED_SIZE,
																				21,
																				GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(
												ComponentPlacement.UNRELATED)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.LEADING)
														.addComponent(
																adress,
																GroupLayout.PREFERRED_SIZE,
																30,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtAdressoptional,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.TRAILING)
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addPreferredGap(
																				ComponentPlacement.UNRELATED)
																		.addComponent(
																				txtPostcodeoptional,
																				GroupLayout.PREFERRED_SIZE,
																				GroupLayout.DEFAULT_SIZE,
																				GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				ComponentPlacement.RELATED,
																				32,
																				Short.MAX_VALUE))
														.addGroup(
																gl_contentPane
																		.createSequentialGroup()
																		.addPreferredGap(
																				ComponentPlacement.RELATED)
																		.addComponent(
																				postecode,
																				GroupLayout.PREFERRED_SIZE,
																				33,
																				GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				ComponentPlacement.UNRELATED)))
										.addPreferredGap(
												ComponentPlacement.UNRELATED)
										.addGroup(
												gl_contentPane
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																btnNewButton,
																GroupLayout.PREFERRED_SIZE,
																42,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																btnNewButton_1,
																GroupLayout.PREFERRED_SIZE,
																43,
																GroupLayout.PREFERRED_SIZE))
										.addContainerGap()));
		contentPane.setLayout(gl_contentPane);
	}
}
