
public class app {
private String gameName,programmerName;
private int downloadNum,strategyNum,simulationNum;
public String getGameName() {
	return gameName;
}
public void setGameName(String gameName) {
	this.gameName = gameName;
}
public String getProgrammerName() {
	return programmerName;
}
public void setProgrammerName(String programmerName) {
	this.programmerName = programmerName;
}
public int getStrategyNum() {
	return strategyNum;
}
public void setStrategyNum(int strategyNum) {
	this.strategyNum = strategyNum;
}
public int getDownloadNum() {
	return downloadNum;
}
public void setDownloadNum(int downloadNum) {
	this.downloadNum = downloadNum;
}
public int getSimulationNum() {
	return simulationNum;
}
public void setSimulationNum(int simulationNum) {
	this.simulationNum = simulationNum;
}
}
