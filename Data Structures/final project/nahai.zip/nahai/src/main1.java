import java.util.Scanner;

public class main1 {
	public static int size, yal, raas, counter;

	public static void main(String[] args) {
		System.out.print("write yal  raas :");
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		String[] sizes = a.split(" ");
		System.out.println("write your graph:");
		yal = Integer.parseInt(sizes[1]);
		raas = Integer.parseInt(sizes[0]);
		size = raas;
		// qavalish rase dovomish yale b rase dg k ba un matris olist azde mishe
		int[] q = new int[Integer.parseInt(sizes[1]) * 2];
		for (int i = 0; i < Integer.parseInt(sizes[1]) * 2; i++) {
			q[i] = sc.nextInt();
			counter++;
		}
		// be matris va list mojavert ezafe mikonim
		matrix.add(q);
		matrix.showMatris();
		// be liste mojavert ezafe krdn
		listMoj.add();
		listMoj.showlist();
		// System.out.println(graph.doNesfe());
		while (graph.doNesfe()) {
			counter++;
			System.out
					.println("******************************************************");
			// cij ha mohasebe mishavad
			graph.hesabeHmeCha();
			graph.cij.viewItems();
			// moratb sazie c ha ba 3 ravesh
			int tmp = counter;

			System.out.println("QuickSort :");
			qiuckSort.QuickSort(graph.cij.cijToArr(graph.cij),
					graph.adresseCij.adCijToArr(graph.adresseCij));
			System.out.println("time:" + counter);
			counter = tmp;

			System.out.println("MergeSort :");
			mergSort.MergeSort(graph.cij.cijToArr(graph.cij),
					graph.adresseCij.adCijToArr(graph.adresseCij));
			System.out.println("time:" + counter);
			counter = tmp;

			// tu imsertion sort taghirat varede khode cij niz mishavad
			System.out.println("InsertionSort :");
			insertionSort.InsertionSort(graph.cij.cijToArr(graph.cij),
					graph.adresseCij.adCijToArr(graph.adresseCij));
			System.out.println("time:" + counter);

			// graph.cij.viewItems();
			// graph.adresseCij.viewItems();

			graph.dobreMortbSazi(graph.boreshi());
		}
		graph.showDoNesfe();
		System.out.println("time:" + counter);
		sc.close();
	}
}
