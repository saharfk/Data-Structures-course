public class graph {
	public static int[] drje = new int[main1.size];
	public static linkedList cij = new linkedList();
	public static linkedList adresseCij = new linkedList();
	public static linkedList nahai = new linkedList();

	public static void daraje() {// miad ba andaze list daraje mige
		for (int i = 0; i < main1.size; i++) {
			main1.counter++;
			linkedList list1 = new linkedList();
			list1 = (linkedList) listMoj.list.viewItem(i);
			drje[i] = list1.itemSize;
			// System.out.println("daraje" + (i+1) + "=" + drje[i]);
		}
	}

	// miad list kuthtro peyda mikone ba mibine k kodum azash b un yeki rass
	// vasln age budn dor++ mishe
	public static int dorebetoole3(int o, int p) {
		int dor = 0;
		for (int i = 0; i < main1.size; i++) {
			main1.counter++;
			if (i != o && i != p && matrix.matris[o][i] == 1
					&& matrix.matris[p][i] == 1) {
				dor++;
			}
		}
		// System.out.println(o +" va "+p+" = "+dor);
		return dor;
	}

	// min yabi
	public static int min(int a, int b) {
		main1.counter++;
		if (a > b)
			return b;
		else
			return a;
	}

	// mohasebe c
	public static int cij(int i, int j) {
		main1.counter++;
		int c = 10000;
		try {
			// System.out.println("door:" + (dorebetoole3(i, j) + 1) + "min:"
			// + min(drje[i] - 1, drje[j] - 1));
			c = (dorebetoole3(i, j) + 1) / (min(drje[i] - 1, drje[j] - 1));
		} catch (ArithmeticException e) {
			c = 10000;
		}
		System.out.println("c" + (1 + i) + (1 + j) + " = " + c);
		return c;

	}

	// c matris balamosalasi k 1 hast ro hesb mikone
	public static void hesabeHmeCha() {
		daraje();
		for (int i = 0; i < main1.size; i++) {
			for (int j = i + 1; j < main1.size; j++) {
				main1.counter++;
				main1.counter++;
				if (matrix.matris[i][j] == 1) {
					cij.addItems("" + cij(i, j));
					adresseCij.addItems(i + " " + j);
				}
			}
		}
	}

	// miad dobre moratab mikone yani miad un raase mariso 0 mikone va tu linked
	// lista ezafe mikone
	public static void dobreMortbSazi(String a) {
		String[] f = a.split(" ");
		int i = Integer.parseInt(f[0]);
		int j = Integer.parseInt(f[1]);
		matrix.matris[i][j] = 0;
		matrix.matris[j][i] = 0;
		matrix.showMatris();
		listMoj.list.itemSize = 0;
		listMoj.add();
		listMoj.showlist();
		cij.itemSize = 0;
		adresseCij.itemSize = 0;

	}

	static int V = main1.raas;
	static int shomarande = 0;
	static boolean flg = false;

	public static void DFSUtil(int v, boolean[] visited) {
		// node ha ro visited mikone va add mishe
		visited[v] = true;
		// System.out.print(v + " ");
		vertexs.addItems(v + "");
		if (v == 0) {
			vertexs.one = 1;
		}
		// Recur for all the vertices
		// adjacent to this vertex
		linkedList list1 = new linkedList();
		list1 = (linkedList) listMoj.list.viewItem(v);
		// list1.viewItems();
		for (int x = 0; x < list1.itemSize; x++) {
			main1.counter++;
			int j = Integer.parseInt((String) list1.viewItem(x));
			if (!visited[j])
				DFSUtil(j, visited);
		}
	}

	static linkedList vertexs = new linkedList();

	public static void connectedComponents() {
		// hme v ha ro not visited mikone
		boolean[] visited = new boolean[V];
		for (int v = 0; v < V; ++v) {
			main1.counter++;
			if (!visited[v]) {
				// v hae y ghsmato chap mikone
				vertexs = new linkedList();
				DFSUtil(v, visited);
				if (flg)
					nahai.addItems(vertexs);
				shomarande++;
				// age bishtr az 2 khat bere paen yni 2 ghsmat ya bishtr az 2
				// ghsmte
				// System.out.println();
			}
		}
	}

	// ,iad ,ibine age shomarande bishtr az 2 bashe yani 2 nesfe shode
	public static boolean doNesfe() {
		main1.counter++;
		shomarande = 0;
		connectedComponents();
		if (shomarande >= 2) {
			flg = true;
			return false;
		} else {
			return true;
		}

	}

	public static int alphabet = 97;

	// aval connected com ha mirn tu list mojavert un listi k tush adade 1 hast
	// alamat mikhore
	// va un "a" mishe va baghie az aval dobre mian va baghie horuf bhshun dde
	// mishe
	public static void showDoNesfe() {
		shomarande = 0;
		connectedComponents();
		// System.out.println(shomarande);
		for (int i = 0; i < nahai.itemSize; i++) {
			main1.counter++;
			if (nahai.one == 1) {
				linkedList l = new linkedList();
				l = (linkedList) nahai.viewItem(i);
				l.showV(l);
				for (int j = 0; j < i; j++) {
					l = new linkedList();
					l = (linkedList) nahai.viewItem(i);
					l.showV(l);
				}
			}
			linkedList l = new linkedList();
			l = (linkedList) nahai.viewItem(i);
			l.showV(l);
		}
	}

	// ***************************BORESHI*************************************
	// miad ta jai k c ha baham dr aval barabarnd ro migire
	// miad az rue adress hzf mikone bad mibine graf joda shode ya na age shode
	// bud k un return mishe age na mire raase boreshio chek mikone
	public static String boreshi() {
		linkedList tmp = new linkedList();
		linkedList listmoji = new linkedList();
		listmoji = listMoj.list;
		if (Integer.parseInt((String) cij.viewItem(0)) != Integer
				.parseInt((String) cij.viewItem(1)))
			return (String) adresseCij.viewItem(0);

		tmp.addItems(cij.viewItem(0));
		for (int i = 0; i < cij.itemSize - 1; i++) {
			main1.counter++;
			if (Integer.parseInt((String) cij.viewItem(i)) == Integer
					.parseInt((String) cij.viewItem(i + 1)))
				tmp.addItems(cij.viewItem(i + 1));
			else
				break;
		}
		for (int j = 0; j < tmp.itemSize; j++) {
			main1.counter++;
			String ad = (String) adresseCij.viewItem(j);
			String[] q = ad.split(" ");
			int x = Integer.parseInt(q[0]);
			int y = Integer.parseInt(q[1]);
			linkedList f = (linkedList) listmoji.viewItem(x);
			// System.out.println(x);
			// listmoji.viewItem(x);
			f.deleteItems(y);
			listmoji.addbejae(x, f);

			f = (linkedList) listmoji.viewItem(y);
			f.deleteItems(x);
			listmoji.addbejae(y, f);

			// TODO hazfe tmp az list moji
			if (doNesfeBoreshi(listmoji)) {
				main1.counter++;
				return (String) adresseCij.viewItem(j);
			}
		}
		return raaseBoreshi();

	}

	public static void DFSUtilBoreshi(int v, boolean[] visited, linkedList lst) {
		// node ha ro visited mikone va add mishe
		visited[v] = true;
		// System.out.print(v + " ");
		vertexs.addItems(v + "");
		if (v == 0) {
			vertexs.one = 1;
		}
		// Recur for all the vertices
		// adjacent to this vertex
		linkedList list1 = new linkedList();
		list1 = (linkedList) listMoj.list.viewItem(v);
		// list1.viewItems();
		for (int x = 0; x < list1.itemSize; x++) {
			main1.counter++;
			int j = Integer.parseInt((String) list1.viewItem(x));
			if (!visited[j])
				DFSUtilBoreshi(j, visited, lst);
		}
	}

	public static void connectedComponentsBoreshi(linkedList lst) {
		// hme v ha ro not visited mikone
		boolean[] visited = new boolean[V];
		for (int v = 0; v < V; ++v) {
			main1.counter++;
			if (!visited[v]) {
				// v hae y ghsmato chap mikone
				vertexs = new linkedList();
				DFSUtilBoreshi(v, visited, lst);
				if (flg)
					nahai.addItems(vertexs);
				shomarande++;
				// age bishtr az 2 khat bere paen yni 2 ghsmat ya bishtr az 2
				// ghsmte
				// System.out.println();
			}
		}
	}

	// ,iad ,ibine age shomarande bishtr az 2 bashe yani 2 nesfe shode
	public static boolean doNesfeBoreshi(linkedList lst) {
		main1.counter++;
		shomarande = 0;
		connectedComponentsBoreshi(lst);
		if (shomarande >= 2) {
			flg = true;
			return false;
		} else {
			return true;
		}

	}

	// miad yalae ba c yksan ro joda mikone bad adresesho brmidre bhsh y matris
	// misaz ba matis listmoj misaze mibine 2 ghsmt shode ya na age shode bud k
	// meghdresho mide age na khune 0 ro mide
	public static String raaseBoreshi() {
		linkedList tmp = new linkedList();
		linkedList list2 = new linkedList();
		linkedList list3 = new linkedList();

		if (Integer.parseInt((String) cij.viewItem(0)) != Integer
				.parseInt((String) cij.viewItem(1)))
			return (String) adresseCij.viewItem(0);

		tmp.addItems(cij.viewItem(0));
		for (int i = 0; i < cij.itemSize - 1; i++) {
			main1.counter++;
			if (Integer.parseInt((String) cij.viewItem(i)) == Integer
					.parseInt((String) cij.viewItem(i + 1)))
				tmp.addItems(cij.viewItem(i + 1));
			else
				break;
		}
		for (int j = 0; j < tmp.itemSize; j++) {
			main1.counter++;
			String ad = (String) adresseCij.viewItem(j);
			String[] q = ad.split(" ");
			int x = Integer.parseInt(q[0]);
			int y = Integer.parseInt(q[1]);
			int[][] smaller = new int[matrix.matris.length - 1][matrix.matris.length - 1];
			// matriso kuchiktr mikone �
			for (int a = 1; a < matrix.matris.length; a++) {
				for (int b = 0; b < matrix.matris.length; b++) {
					main1.counter++;
					if (b < x) {
						smaller[a - 1][b] = matrix.matris[a][b];
					} else if (b > x) {
						smaller[a - 1][b - 1] = matrix.matris[a][b];
					}
				}
			}

			for (int k = 0; k < main1.raas - 1; k++) {
				linkedList list1 = new linkedList();
				for (int l = 0; l < main1.size - 1; l++) {
					main1.counter++;
					main1.counter++;
					if (smaller[k][l] == 1) {
						list1.addItems(l + "");
					}
				}
				list2.addItems(list1);
			}

			if (doNesfeBoreshi(list2)) {
				main1.counter++;
				return (String) adresseCij.viewItem(j);
			}

			// ********************************************y
			int[][] smaller1 = new int[matrix.matris.length - 1][matrix.matris.length - 1];
			// matriso kuchiktr mikone �
			for (int a = 1; a < matrix.matris.length; a++) {
				for (int b = 0; b < matrix.matris.length; b++) {
					main1.counter++;
					if (b < y) {
						smaller1[a - 1][b] = matrix.matris[a][b];
					} else if (b > y) {
						smaller1[a - 1][b - 1] = matrix.matris[a][b];
					}
				}
			}

			for (int k = 0; k < main1.raas - 1; k++) {
				linkedList list1 = new linkedList();
				for (int l = 0; l < main1.size - 1; l++) {
					main1.counter++;
					main1.counter++;
					if (smaller[k][l] == 1) {
						list1.addItems(l + "");
					}
				}
				list3.addItems(list1);
			}
			if (doNesfeBoreshi(list3)) {
				return (String) adresseCij.viewItem(j);
			}

		}

		return (String) adresseCij.viewItem(0);

	}

}
