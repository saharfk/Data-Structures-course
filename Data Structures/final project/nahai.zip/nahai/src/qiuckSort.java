public class qiuckSort {
	// akharin elemente ye ghsmato migire bozorgtarasho mirize tu ye araye
	// kuchiktarashm tu ye araye dg bad hamunaram hmitori unghad sort mikone ta
	// yedune bshn
	static int partition(int arr[], String adress[], int low, int high) {
		int pivot = arr[high];
		int i = (low - 1); // index kuchktrin element
		for (int j = low; j < high; j++) {
			// age element khuchiktr ya mosavie pivot bud
			if (arr[j] <= pivot) {
				i++;
				// swap arr[i] and arr[j]
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;

				String ad = adress[i];
				adress[i] = adress[j];
				adress[j] = ad;
			}
		}

		// swap arr[i+1] and arr[high] (ya pivot)
		int temp = arr[i + 1];
		arr[i + 1] = arr[high];
		arr[high] = temp;

		String ad = adress[i + 1];
		adress[i + 1] = adress[high];
		adress[high] = ad;

		return i + 1;
	}

	/*
	 * tabe main k implement mikone QuickQsort() ro arr[] --> Array k ghrre
	 * Qsort beshe, low --> index shuru, high --> index payan , adress -->
	 * adresse c ha
	 */
	public static void Qsort(int arr[], String adress[], int low, int high) {
		if (low < high) {
			/*
			 * pi partitioning indexe, arr[pi]aln tu jae dorsteshe
			 */
			int pi = partition(arr, adress, low, high);

			// partition va bade partition bazgashti
			Qsort(arr, adress, low, pi - 1);
			Qsort(arr, adress, pi + 1, high);
		}
	}

	// print mikone
	static void printArray(int arr[], String adress[]) {
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");
		System.out.println();
		for (int i = 0; i < n; ++i)
			System.out.print(adress[i] + ",");
		System.out.println();
	}

	public static void QuickSort(int arr[], String adress[]){
		Qsort(arr, adress, 0, graph.cij.itemSize-1);
		printArray(arr, adress);
	}
	
	
	
	
	
	// emtehani
	public static void main(String args[]) {
		int arr[] = { 10, 7, 8, 9, 1, 5 };
		String adress[] = { "10", "7", "8", "9", "1", "5" };
		// int n = arr.length;
		// TODO
		qiuckSort ob = new qiuckSort();
		ob.Qsort(arr, adress, 0, arr.length - 1);

		System.out.println("sorted array");
		printArray(arr, adress);
	}
}
