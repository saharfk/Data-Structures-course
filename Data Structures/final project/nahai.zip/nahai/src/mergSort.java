public class mergSort {
	static// Merges two subarrays of arr[].
	// First subarray is arr[l..m]
	// Second subarray is arr[m+1..r]
	void merge(int arr[], String adress[], int l, int m, int r) {
		// peyda krdne andaze arraye ha
		int n1 = m - l + 1;
		int n2 = r - m;

		int L[] = new int[n1];
		int R[] = new int[n2];

		String Lad[] = new String[n1];
		String Rad[] = new String[n2];
		/* Copy data be temp arrayha */
		for (int i = 0; i < n1; ++i) {
			L[i] = arr[l + i];
			Lad[i] = adress[l + i];
		}
		for (int j = 0; j < n2; ++j) {
			R[j] = arr[m + 1 + j];
			Rad[j] = adress[m + 1 + j];
		}

		/* Merge krdne temp arrays */

		// Initial indexes of first and second subarrays
		int i = 0, j = 0;

		// Initial index of merged subarry array
		int k = l;
		while (i < n1 && j < n2) {
			if (L[i] <= R[j]) {
				arr[k] = L[i];
				adress[k] = Lad[i];
				i++;
			} else {
				arr[k] = R[j];
				adress[k] = Rad[j];
				j++;
			}
			k++;
		}

		/* Copy remaining elements of L[] if any */
		while (i < n1) {
			arr[k] = L[i];
			adress[k] = Lad[i];
			i++;
			k++;
		}

		/* Copy remaining elements of R[] if any */
		while (j < n2) {
			arr[k] = R[j];
			adress[k] = Rad[j];
			j++;
			k++;
		}
	}

	// tabe aslie sort
	public static void mergesort(int arr[], String adress[], int l, int r) {
		if (l < r) {
			// peyda krdne noghte vasat
			int m = (l + r) / 2;

			// Sort mikone ghsmte aval va dovom ro
			mergesort(arr, adress, l, m);
			mergesort(arr, adress, m + 1, r);

			// Merge mikone ghsmthae sort shode ro
			merge(arr, adress, l, m, r);
		}
	}

	// print
	public static void printArray(int arr[], String adress[]) {
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");
		System.out.println();
		for (int i = 0; i < n; ++i)
			System.out.print(adress[i] + ",");
		System.out.println();
	}

	public static void MergeSort(int arr[], String adress[]) {
		mergesort(arr, adress, 0, graph.cij.itemSize - 1);
		printArray(arr, adress);
	}

	// emtehan
	// public static void main(String args[]) {
	// int arr[] = { 10, 7, 8, 9, 1, 5 };
	// String adress[] = { "10", "7", "8", "9", "1", "5" };
	// System.out.println("Given Array");
	// printArray(arr, adress);
	//
	// mergSort ob = new mergSort();
	// ob.mergesort(arr, adress, 0, arr.length - 1);
	//
	// System.out.println("\nSorted array");
	// printArray(arr, adress);
	// }
}