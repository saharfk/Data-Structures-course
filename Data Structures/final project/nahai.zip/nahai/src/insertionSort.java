public class insertionSort {
	public static void insSort(int arr[], String adress[]) {
		int n = arr.length;
		for (int i = 1; i < n; ++i) {
			int key = arr[i];
			String ad = adress[i];
			int j = i - 1;

			// miad b trtib ozv b ozv check mikone ba ghablish age azash kuchik
			// tr bud ja b ja mishe unghd b aghab negah mikone ta bozorgtresh
			// nabashe bad meghdaresh mire tue un
			while (j >= 0 && arr[j] > key) {
				adress[j + 1] = adress[j];
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = key;
			adress[j + 1] = ad;
		}
	}

	// **********************************
	static void printArray(int arr[], String adress[]) {
		int n = arr.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");

		System.out.println();
		for (int i = 0; i < n; ++i)
			System.out.print(adress[i] + ",");
		System.out.println();
		graph.cij = new linkedList();
		graph.adresseCij = new linkedList();
		for (int i = 0; i < n; i++) {
			graph.cij.addItems(arr[i] + "");
			graph.adresseCij.addItems(adress[i]);
		}
	}

	public static void InsertionSort(int arr[], String adress[]) {
		insSort(arr, adress);
		printArray(arr, adress);
	}

	// emtehan
	// public static void main(String[] args) {
	// int arr[] = { 10, 7, 8, 9, 1, 5 };
	// String adress[] = { "10", "7", "8", "9", "1", "5" };
	// insSort(arr, adress);
	// printArray(arr, adress);
	// }
}
