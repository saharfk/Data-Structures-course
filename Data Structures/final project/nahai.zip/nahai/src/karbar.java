public class karbar {
	private String name;
	private linkedList downloadedApp = new linkedList();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public linkedList getDownloadedApp() {
		return downloadedApp;
	}

	public void setDownloadedApp(String downloadedApp) {
		this.downloadedApp.addItems(downloadedApp);
	}

}
