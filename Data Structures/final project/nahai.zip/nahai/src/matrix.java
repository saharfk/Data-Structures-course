public class matrix {
	public static int[][] matris = new int[main1.size][main1.size];

	// q ro varede matris mikone
	public static void add(int[] q) {
		for (int i = 0; i < q.length; i++) {
			main1.counter++;
			if (i % 2 != 0) {
				matris[q[i] - 1][q[i - 1] - 1] = 1;
				matris[q[i - 1] - 1][q[i] - 1] = 1;
			}
		}

	}

	// matris ro neshun mide
	public static void showMatris() {
		for (int i = 0; i < main1.size; i++) {
			for (int j = 0; j < main1.size; j++) {
				main1.counter++;
				System.out.print(matris[i][j] + " ");
			}
			System.out.println();
		}
	}
}
