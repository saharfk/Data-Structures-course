import java.util.Scanner;

public class main2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("how many apps??");
		int appnum = sc.nextInt();

		app[] applicaition = new app[appnum];
		for (int i = 0; i < appnum; i++) {
			applicaition[i] = new app();
			System.out.println("name of the game :");
			applicaition[i].setGameName(sc.next());
			System.out.println("Programmer Name :");
			applicaition[i].setProgrammerName(sc.next());
		}

		System.out.println("how many users??");
		int usernum = sc.nextInt();

		karbar[] users = new karbar[usernum];
		for (int i = 0; i < usernum; i++) {
			users[i] = new karbar();
			System.out.println("user's name :");
			users[i].setName(sc.next());
			for (int j = 0; j < appnum; j++) {
				System.out.println("did you downloaded the  "
						+ applicaition[i].getGameName()
						+ "? 1 = yes  /  2 = no");
				int yesNo = sc.nextInt();
				if (yesNo == 1) {
					users[i].setDownloadedApp(i + "");
					System.out.println("your rate for Simulation to "
							+ applicaition[i].getGameName() + " :");
					int rate = sc.nextInt();
					applicaition[i].setSimulationNum(rate);
					while (rate < 0 && rate > 5) {
						System.out.println("rate must be between 0 and 5!");
						applicaition[i].setSimulationNum(sc.nextInt());
					}

					System.out.println("your rate for Strategy to "
							+ applicaition[i].getGameName() + " :");
					rate = sc.nextInt();
					applicaition[i].setStrategyNum(rate);
					while (rate < 0 && rate > 5) {
						System.out.println("rate must be between 0 and 5!");
						applicaition[i].setStrategyNum(sc.nextInt());
					}
				}
			}
		}


	}
}
