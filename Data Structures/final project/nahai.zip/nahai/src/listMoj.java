public class listMoj {
	public static linkedList list = new linkedList();

	// ba estefade az matris list ro mize(be edade raasa linklist misaze va
	// tushun rasae yaldar rikhte mishe)
	public static void add() {
		for (int i = 0; i < main1.raas; i++) {
			linkedList list1 = new linkedList();
			for (int j = 0; j < main1.size; j++) {
				main1.counter++;
				if (matrix.matris[i][j] == 1) {
					list1.addItems(j + "");
				}
			}
			list.addItems(list1);
		}

	}
	
	public static void add(int[][] mat,linkedList list) {
		for (int i = 0; i < main1.raas; i++) {
			linkedList list1 = new linkedList();
			for (int j = 0; j < main1.size; j++) {
				main1.counter++;
				if (mat[i][j] == 1) {
					list1.addItems(j + "");
				}
			}
			list.addItems(list1);
		}

	}

	public static void showlist() {
		for (int i = 0; i < list.itemSize; i++) {
			main1.counter++;
			linkedList list1 = new linkedList();
			list1 = (linkedList) list.viewItem(i);
			System.out.print(i + 1 + " : ");
			list1.showItems();
		}
	}
}
