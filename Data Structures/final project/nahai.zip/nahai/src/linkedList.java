public class linkedList {
	public Object item[] = new Object[1000];
	int itemSize = 0, one = 0;
	private int currentLoc;

	// akharin iteme arr k tush pore ro negah midre o az un kmo ziad mikone
	public void addItems(Object element) {
		if (element != null) {
			main1.counter++;
			item[itemSize] = element;
			itemSize++;
		}
	}

	public void deleteItems(Object element) {
		int flag = 0;
		if (itemSize > 0) {
			for (int i = 0; i < itemSize; i++) {
				main1.counter++;
				if (item[i] == element) {
					flag = 1;
					currentLoc = i;
					break;
				}
			}
			if (flag == 0)
				System.out.println("No such element to delete such as '"
						+ element + "'");
			else if (flag == 1) {
				for (int i = currentLoc + 1; i < itemSize; i++) {
					main1.counter++;
					item[currentLoc] = item[i];
					currentLoc++;
				}
				itemSize--;
				// System.out.println("'" + element + "' element is deleted");
			}
		}
	}

	// hame item haro neshun mide
	public void viewItems() {
		if (itemSize > 0) {
			for (int i = 0; i < itemSize; i++) {
				main1.counter++;
				System.out.print(item[i] + " ");
			}
			System.out.println();
		}
	}

	public Object viewItem(int element) {
		return item[element];
	}

	// tbdil cij va adressesh b araye
	public int[] cijToArr(linkedList a) {
		int[] cijAsArray = new int[a.itemSize];
		for (int i = 0; i < a.itemSize; i++) {
			main1.counter++;
			cijAsArray[i] = Integer.parseInt((String) a.viewItem(i));
		}
		return cijAsArray;

	}

	// tabdil b arraye barae sort krdn
	public String[] adCijToArr(linkedList a) {
		String[] ADcijAsArray = new String[a.itemSize];
		for (int i = 0; i < a.itemSize; i++) {
			main1.counter++;
			ADcijAsArray[i] = (String) a.viewItem(i);
		}
		return ADcijAsArray;

	}

	public void showItems() {
		if (itemSize == 0) {
			System.out.println("null");
		}
		if (itemSize > 0) {
			for (int i = 0; i < itemSize; i++) {
				main1.counter++;
				if (i == itemSize - 1)
					System.out.print((Integer.parseInt(item[i] + "") + 1));
				else
					System.out.print((Integer.parseInt(item[i] + "") + 1)
							+ " , ");
			}
			System.out.println();
		}

	}

	// chape nahai
	public void showV(linkedList list) {
		for (int i = 0; i < list.itemSize; i++) {
			main1.counter++;
			char f = (char) graph.alphabet;
			System.out.println("#"
					+ (Integer.parseInt((String) list.viewItem(i)) + 1) + " : "
					+ f);
		}
		graph.alphabet++;
	}

	public void deleteItems(int y) {
		// TODO Auto-generated method stub
		for (int i = y; i < itemSize - 1; i++) {
			main1.counter++;
			item[i] = item[i + 1];
		}
	}

	public void addbejae(int x, linkedList f) {
		main1.counter++;
		// TODO Auto-generated method stub
		item[x] = f;
	}
}
