package codeGozariP3;

import java.util.Random;
import java.util.Scanner;

public class codeGozariP3 {
	static int[] randomInt = new int[26];
	static String[] alphabet = { "a", "b", "c", "d", "e", "f", "g", "h", "i",
			"j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
			"w", "x", "y", "z" };

	static int max = 27;

	static int[] heap = new int[max];
	static int size = 0;

	static void insert(int element) {
		heap[0] = 1000000;
		heap[++size] = element;
		int current = size;
		while (heap[current] > heap[parent(current)]) {
			swap(current, parent(current), heap);
			current = parent(current);
		}
	}

	static int heapSize(int[] heap) {
		int i;
		for (i = 0; i < heap.length; i++) {
			if (i != heap.length - 1) {
				if (heap[i] == 0 && heap[i + 1] == 0) {
					break;
				}
			}
		}
		return i;
	}

	static void insertQ(int element, int[] heap) {
		heap[0] = 1000000;
		heap[heapSize(heap)] = element;
		int current = heapSize(heap) - 1;
		while (heap[current] > heap[parent(current)]) {
			swap(current, parent(current), heap);
			current = parent(current);
		}

	}

	static int deleteMinQ(int[] heap) {
		int popped = heap[FRONT];
		heap[FRONT] = heap[heapSize(heap)];
		heap[heapSize(heap)] = 0;
		maxHeapify(FRONT, heap);
		return popped;

	}

	public static int parent(int pos) {
		return pos / 2;
	}

	public static int leftChild(int pos) {
		return (2 * pos);
	}

	public static int rightChild(int pos) {
		return (2 * pos) + 1;
	}

	public static boolean isLeaf(int pos) {
		if (pos >= (size / 2) && pos <= size) {
			return true;
		}
		return false;
	}

	public static void swap(int fpos, int spos, int[] heap) {
		int tmp;
		tmp = heap[fpos];
		heap[fpos] = heap[spos];
		heap[spos] = tmp;
	}

	public static void maxHeap() {
		for (int pos = (size / 2); pos >= 1; pos--) {
			maxHeapify(pos, heap);
		}
	}

	private static void maxHeapify(int pos, int[] heap) {
		if (!isLeaf(pos)) {
			if (heap[pos] < heap[leftChild(pos)]
					|| heap[pos] < heap[rightChild(pos)]) {
				if (heap[leftChild(pos)] > heap[rightChild(pos)]) {
					swap(pos, leftChild(pos), heap);
					maxHeapify(leftChild(pos), heap);
				} else {
					swap(pos, rightChild(pos), heap);
					maxHeapify(rightChild(pos), heap);
				}
			}
		}
	}

	private static final int FRONT = 1;

	public static int remove() {
		int popped = heap[FRONT];
		heap[FRONT] = heap[size];
		heap[size] = 0;
		size--;
		maxHeapify(FRONT, heap);
		return popped;
	}

	public static void print() {
		for (int i = 1; i <= size / 2; i++) {
			System.out.print(" PARENT : " + heap[i] + " LEFT CHILD : "
					+ heap[2 * i] + " RIGHT CHILD :" + heap[2 * i + 1]);
			System.out.println();
		}
	}

	// *******************************heap
	public static String javab(int[] heap, String[] jomle) {// TODO
		String qp = null;
		int negahdrnde = -1;
		for (int i = 0; i < jomle.length; i++) {
			// adade kelidii k be hrfe jomle ekhtesas dade shode
			while (randomInt[adadeHarf(jomle[i])] != heap[1]) {
				counter++;
				queue[taheQueue] = remove();
				taheQueue++;
				// hzf az heap ta jae k b hrfe morede nzr brsim
				if (size == 0) {
					break;
				}
			}
			if (randomInt[adadeHarf(jomle[i])] == heap[1]) {
				// agar dr saf bud
				negahdrnde = remove();
				// qp += alphabet[negahdrnde];
				queue[taheQueue++] = negahdrnde;
				addingQ(heap, queue, jomle[i]);
				notAddingQ(heap, jomle[i]);
				// swap
				int y = randomInt[adadeHarf(alphabet[negahdrnde])];
				randomInt[adadeHarf(alphabet[negahdrnde])] = randomInt[adadeHarf(jomle[i])];
				randomInt[adadeHarf(jomle[i])] = y;
			}
		}

		return qp;

	}

	static int counter = 0, count = 0;

	private static String notAddingQ(int[] heap2, String jomle) {
		String qp = null;
		counter = 0;
		int negahdrnde = -1;
		int[] queue22 = new int[26];
		// TODO Auto-generated method stub
		// if (count == 0) {
		// System.out.println(notAddingQ(heap2, jomle));
		// System.out.println(addingQ(heap2, queue22, jomle));
		// count++;
		// } else {
		// adade kelidii k be hrfe jomle ekhtesas dade shode
		while (randomInt[adadeHarf(jomle)] != heap[0]) {
			counter++;
			queue[taheQueue++] = remove();
			// hzf az heap ta jae k b hrfe morede nzr brsim
			if (size == 0) {
				break;
			}
		}
		if (randomInt[adadeHarf(jomle)] == heap[0]) {
			// agar dr saf bud
			negahdrnde = remove();
			// qp += alphabet[negahdrnde];
			queue[taheQueue++] = negahdrnde;
			System.out.println(addingQ(heap, queue, jomle));
			System.out.println(notAddingQ(heap, jomle));
			// swap
			int y = randomInt[adadeHarf(alphabet[negahdrnde])];
			randomInt[adadeHarf(alphabet[negahdrnde])] = randomInt[adadeHarf(jomle)];
			randomInt[adadeHarf(jomle)] = y;
		}

		// }
		return qp + alphabet[counter];
	}

	private static String addingQ(int[] heap2, int[] queue2, String jomle) {
		String qp = null;
		counter = 0;
		int negahdrnde = -1;
		int[] queue22 = new int[26];
		// TODO
		if (count == 0) {
			for (int i = 0; i < sizequeue(queue2); i++) {
				if (heapSize(heap2) != 27 || heapSize(heap2) != 26)
					insertQ(queue2[i], heap2);
			}

			System.out.println(notAddingQ(heap2, jomle));
			System.out.println(addingQ(heap2, queue22, jomle));
			count++;
		} else {
			int k = sizequeue(queue2);
			for (int i = 0; i < k; i++) {
				insertQ(queue2[i], heap2);
			}
			// adade kelidii k be hrfe jomle ekhtesas dade shode
			while (randomInt[adadeHarf(jomle)] != heap[0]) {
				counter++;
				queue[taheQueue++] = remove();
				// hzf az heap ta jae k b hrfe morede nzr brsim
				if (size == 0) {
					break;
				}
			}
			if (randomInt[adadeHarf(jomle)] == heap[0]) {
				// agar dr saf bud
				negahdrnde = remove();
				// qp += alphabet[negahdrnde];
				queue[taheQueue++] = negahdrnde;
				System.out.println(addingQ(heap, queue, jomle));
				System.out.println(notAddingQ(heap, jomle));
				// swap
				int y = randomInt[adadeHarf(alphabet[negahdrnde])];
				randomInt[adadeHarf(alphabet[negahdrnde])] = randomInt[adadeHarf(jomle)];
				randomInt[adadeHarf(jomle)] = y;
			}

		}
		return qp + alphabet[counter];
	}

	private static int sizequeue(int[] queue2) {

		int i;
		for (i = 0; i < queue2.length; i++) {
			if (i != queue2.length - 1) {
				if (queue2[i] == 0 && queue2[i + 1] == 0) {
					break;
				}
			}
		}
		return i;

	}

	static Random rand = new Random();
	static int taheQueue = 0;
	static int[] queue = new int[26];

	// static int[] arr = new int[26];

	public static void randomize() {

		int k = -1, i = 0;
		while (i < randomInt.length) {
			int flg = -1;
			k = rand.nextInt(26);
			for (int j = 0; j < i; j++) {
				if (randomInt[j] == k) {
					flg++;
					break;
				}
			}
			if (flg == -1) {
				randomInt[i] = k;
				i++;
			}
		}
		// for (int i1 = 0; i1 < randomInt.length; i1++)
		// System.out.print(randomInt[i1] + " ");

	}

	public static int adadeHarf(String a) {
		int k = 0;
		for (int i = 0; i < alphabet.length; i++) {
			if (alphabet[i].equals(a) == true) {
				k = i;
				break;
			}
		}
		return k;
	}

	public static void main(String[] args) {
		System.out.println("salam");
		while (true) {
			System.out.println("mikhai 1.ramzgozari koni ya 2.ramzgoshai");
			Scanner sc = new Scanner(System.in);
			int k = sc.nextInt();
			// ************************************************************ramz
			// negari
			if (k == 1) {
				System.out.println("matne ramz ro benevis : ");
				randomize();// ekhtesas adad be horuf
				for (int i = 0; i < randomInt.length; i++) {
					insert(randomInt[i]);// vorud adade horuf be max heap
				}
				String ramz = sc.next();
				String[] ramz2 = ramz.split("");
				for (int i = 0; i < ramz2.length; i++) {
					int p = randomInt[adadeHarf(ramz2[i])];
					// adade randome harfe entekhab shode ro peyda mikone
					if (p <= size) {
						// tedade anasore heap
						for (int adad = 0; adad < p; adad++) {
							// hzfe rishe be tedade adade hrf
							queue[taheQueue] = remove();
							if (adad == p - 1) {
								System.out.print(alphabet[queue[taheQueue]]);
								// harfe saf
								// swap
								int q = randomInt[adadeHarf(alphabet[queue[taheQueue]])];
								randomInt[adadeHarf(alphabet[queue[taheQueue]])] = randomInt[adadeHarf(ramz2[i])];
								randomInt[adadeHarf(ramz2[i])] = q;
								// jabejae adade harfe ghable ramznegari ba bade
								// ramz negari
							}
							taheQueue++;
						}
					} else {
						for (int f = 0; f < taheQueue; f++) {
							insert(queue[k]);
							if (f == taheQueue - 1) {
								taheQueue = 0;
								i--;
							}
						}
					}
				}

				// *************************************************ramz goshai
			} else if (k == 2) {
				Scanner src = new Scanner(System.in);
				int f = 0;
				System.out.println("kelid ra vared konid :");
				String key1 = src.nextLine();
				System.out.println("jomle ra vared konid :");
				String jomle1 = src.nextLine();
				String[] jomle = jomle1.split("");
				String[] key = key1.split(" |_");

				for (int i = 0; i < key.length; i++) {
					if (i % 2 != 0) {
						randomInt[f] = Integer.parseInt(key[i]);
						f++;
					}
				}
				for (int i = 0; i < randomInt.length; i++) {
					insert(randomInt[i]);
				}
				// ********
				javab(heap, jomle);// TODO
				// ******************************************************else
			} else
				System.out.println("adade eshtebah");
			// ****************************************************
			System.out.println("\ncountinue?1.no /else.yes");
			int j = sc.nextInt();
			if (j == 1) {
				System.out.println("BYE!!!!");
				break;
			} else {
				for (int i = 0; i < size; i++) {
					remove();
				}
				size = 0;
				for (int i = 0; i < queue.length; i++) {
					queue[i] = 0;
				}
				taheQueue = 0;
			}
		}
	}
}
