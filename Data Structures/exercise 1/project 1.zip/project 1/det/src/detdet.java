import java.util.Scanner;

public class detdet {

	public static String CNMAA(String a, String b, int l) {

		// ba + o i joda mikone mirizateshun tuye arraye bad tabdil b adadeshun
		// mikone
		String x[] = a.split("\\+|i");
		String y[] = b.split("\\+|i");

		int a_real = Integer.parseInt(x[0]);
		int a_img = Integer.parseInt(x[1]);
		int b_real = Integer.parseInt(y[0]);
		int b_img = Integer.parseInt(y[1]);

		if (l == 1) {
			if (ss == 1)
				return (a_real * b_real - a_img * b_img) + "+"
						+ (a_real * b_img + a_img * b_real) + "i";
			else
				return ((a_real * b_real - a_img * b_img) * -1) + "+"
						+ ((a_real * b_img + a_img * b_real)) * -1 + "i";
		} else
			return (a_real + b_real) + "+" + (a_img + b_img) + "i";

	}

	static int ss;

	public static String detComplex(String[][] matris) {
		String sum = "0+0i";
		if (matris.length == 1) {// age natris 1*1 bud detesh mishe khode matris
			return (matris[0][0]);
		}
		for (int i = 0; i < matris.length; i++) {
			String[][] smaller = new String[matris.length - 1][matris.length - 1];
			// matriso kuchiktr mikone  
			for (int a = 1; a < matris.length; a++) {
				for (int b = 0; b < matris.length; b++) {
					if (b < i) {
						smaller[a - 1][b] = matris[a][b];
					} else if (b > i) {
						smaller[a - 1][b - 1] = matris[a][b];
					}
				}
			}
			if (i % 2 == 0) { // taghire alamate (-1)^n ba estefade az
								// baghimandegiri
				ss = 1;
			} else {
				ss = -1;
			}
			sum = CNMAA(
					sum,
					CNMAA(matris[0][i],
							detComplex(smaller), 1), 0);
			// ba estefade az tabe zarbo jame mokhtalet va formule det javab ro
			// bedast miare va ba javabe ghabl jam mikone
		}
		return (sum);
		// javabe nahayi ro return mikone
	}

	public static double det(double[][] matris) {
		double sum = 0;
		int s;
		if (matris.length == 1) {// age natris 1*1 bud detesh mishe khode matris
			return (matris[0][0]);
		}
		for (int i = 0; i < matris.length; i++) {
			// matriso kuchiktr mikone  
			double[][] smaller = new double[matris.length - 1][matris.length - 1];
			for (int a = 1; a < matris.length; a++) {
				for (int b = 0; b < matris.length; b++) {
					if (b < i) {
						smaller[a - 1][b] = matris[a][b];
					} else if (b > i) {
						smaller[a - 1][b - 1] = matris[a][b];
					}
				}
			}
			if (i % 2 == 0) { // taghire alamate (-1)^n ba estefade az
				// baghimandegiri
				s = 1;
			} else {
				s = -1;
			}
			sum += s * matris[0][i] * (det(smaller));
			// ba estefade az formule det javab ro
			// bedast miare va ba javabe ghabl jam mikone(ghesmate bazgashti
			// dastan)
		}
		return (sum);
		// javabe nahayi ro return mikone
	}

	public static void main(String[] args) {
		while (true) {
			Scanner src = new Scanner(System.in);
			System.out.println("1.complex / 2.normal?");
			int choice = src.nextInt();
			if (choice == 2) {
				System.out
						.print("write the size of the matris that you want  :  ");
				int a = src.nextInt();
				double[][] matris = new double[a][a];
				System.out.println("write your matris :");
				for (int i = 0; i < a; i++) {
					for (int j = 0; j < a; j++) {
						matris[i][j] = src.nextDouble();
					}
				}
				// **************************************3rghm ashar
				String adad = Double.toString(det(matris));
				String x[] = adad.split("\\.");
				if (x[1].length() == 1) {
					System.out.println("\n*************************\n\n"
							+ "your det is = " + adad + "00"
							+ "\n\n*************************\n");
				} else if (x[1].length() == 2) {
					System.out.println("\n*************************\n\n"
							+ "your det is = " + adad + "0"
							+ "\n\n*************************\n");
				} else if (x[1].length() == 3) {
					System.out.println("\n*************************\n\n"
							+ "your det is = " + adad
							+ "\n\n*************************\n");
				} else {
					System.out.println("\n*************************\n\n"
							+ "your det is = " + x[0] + "."
							+ x[1].substring(0, 3)
							+ "\n\n*************************\n");
				}
			}
			// ********************************************************************************************************
			// ********************************************************************************************************
			// ********************************************************************************************************
			// ********************************************************************************************************
			else if (choice == 1) {
				// ****************complex

				System.out
						.print("write the size of the matris that you want  :  ");
				int a = src.nextInt();
				String[][] matris = new String[a][a];
				System.out.println("write your matris :");
				for (int i = 0; i < a; i++) {
					for (int j = 0; j < a; j++) {
						matris[i][j] = src.next();
					}
				}
				// **********************************
				System.out.println("\n*************************\n\n"
						+ "your det is = " + detComplex(matris)
						+ "\n\n*************************\n");

			}
			// *************************************

			System.out.println(" do you want to countinue?\n1.yes\n2.no");
			int k = src.nextInt();
			if (k == 2)
				break;
			src.close();
		}

	}

}
