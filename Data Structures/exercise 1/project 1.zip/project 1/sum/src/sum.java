import java.util.ArrayList;
import java.util.Scanner;

public class sum {
	public static void main(String[] args) {
		Scanner src = new Scanner(System.in);
		String series[] = null;
		int yy = 0;
		while (yy == 0) {// chek mikone agar {} bud error mide
			System.out.println("write your array :");
			String a = src.next();
			series = a.split("");
			for (int i = 0; i < series.length; i++) {
				if (series[i].equals("{") == true) {
					if (series[i + 1].equals("}") == true) {
						System.out.println("eror!!wrong array");
						break;
					}
				}
				if (i == series.length - 1)
					yy++;
			}
		}
		ArrayList serie = new ArrayList();
		for (int i = 0; i < series.length; i++) {
			// "," haro joda mikone va bdune "," mirize tu araye
			if (series[i].equals(",") == false) {
				serie.add(series[i]);
			}
		}
		addition(serie);
		src.close();
	}

	public static int addition(ArrayList serie) {
		// az aval hme ro jm mikone age be { berese dakhelesho aval baz bahm jam
		// mikone chap mikone bad ba edame majara jm mikone
		int sum = 0, baz = 0, baste = 0, i_baz = 0, i_baste = 0;
		for (int i = 1; i < serie.size() - 1; i++) {
			if (serie.get(i).equals("{") == false && baz == 0) {
				// shru mikone az aval hme ro chap krdn
				sum += Integer.parseInt((String) serie.get(i));
				if (i == serie.size() - 1) {// jame dakhele {} tamumshode
					System.out.println(sum);
				}
			} else {
				if (serie.get(i).equals("{") == true) {
					// i e "{" ro save mikone vaghti tedade { ba } barabar beshe
					// un ghsmte araye ro dobre mide be tabe
					baz++;
					if (baz == 1)
						i_baz = i;
				}
				if (serie.get(i).equals("}") == true) {
					baste++;
					if (baste == baz) {
						i_baste = i;
						baz = 0;
						baste = 0;
					}
					ArrayList s = new ArrayList();
					for (int j = i_baz; j <= i_baste; j++)
						s.add(serie.get(j));
					sum += addition(s);
				}
			}
		}
		System.out.println(sum);
		return sum;
	}
}
